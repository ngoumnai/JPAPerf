/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.heigvd.jpaperf.model;

/**
 *
 * @author gauss
 */
public enum EventType {
    
    Conference,
    Holiday,
    Internship,
    Interview,    
    Laboratory,
    Lecture,
    Reception,
    Showing,
    Sick,
    Symposium;
}
