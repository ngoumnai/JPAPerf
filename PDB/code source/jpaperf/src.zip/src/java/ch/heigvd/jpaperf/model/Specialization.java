/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.heigvd.jpaperf.model;

/**
 *
 * @author gauss
 */
public enum Specialization {
    Financial_engineering, Microtechnology,
    Industrial_systems, Media_engineering,
    Network_and_services, IT_security,    
    Engineering_Management, IT_Management,
    Thermal_Thermotronique, Electricity, 
    Electronics, Industrial_Automation, 
    Onboard_electronics_mechatronics, Physics,
    Energy_systems, Software_engineering,
    Industrial_Design, Mechatronics,
    Embedded_computing, Systems_management,
    Environmental_engineering, Economy, 
    Construction_and_infrastructure, Chemistry,
    Geomatics_and_Land_management, Mathematics;
}
